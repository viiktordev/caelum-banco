package br.com.caelum.contas.main;

import br.com.caelum.contas.modelo.Conta;
import br.com.caelum.contas.modelo.Data;

public class Sistema {
	
 public static void main(String[] args) {
	Data data = new Data();
	data.setDia(23);
	data.setMes(03);
	data.setAno(2019);
	
	Conta c1 = new Conta("Victor", "2363-0", data);
	
	c1.deposita(1000);
	System.out.println(c1.getSaldo());
	
	c1.saca(250);
	System.out.println(c1.getSaldo());
	
	System.out.println(c1.getDataAbertura());
	
}
}
