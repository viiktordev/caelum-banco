package br.com.caelum.contas.modelo;


/**
 * 
 * @author oo8163
 *
 */
public class Conta{
	private static int contNumCotna = 0;
    private String titular;
    private int numero;
    private String agencia;
    private double saldo;
    private Data dataAbertura;
    
    public Conta(String titular, String agencia, Data dataAbertura){
        this.titular = titular;
        this.numero = contNumCotna +1;
        this.agencia = agencia;
        this.dataAbertura = dataAbertura;
    }

    public void deposita(double valor){
        this.saldo += valor;
    }

    public void saca (double valor){
        this.saldo -= valor;
    }

    public double calculaRendimento(){
        return this.saldo * 0.1;
    }

	public double getSaldo() {
		return this.saldo;
	}
	
	public String getDataAbertura() {
		return this.dataAbertura.getDataFormatada();
	}
	
	
}